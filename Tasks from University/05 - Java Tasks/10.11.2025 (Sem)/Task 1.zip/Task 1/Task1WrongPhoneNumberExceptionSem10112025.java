public class Task1WrongPhoneNumberExceptionSem10112025 extends Exception {
    public Task1WrongPhoneNumberExceptionSem10112025(String message) {
        super(message);
    }
}
