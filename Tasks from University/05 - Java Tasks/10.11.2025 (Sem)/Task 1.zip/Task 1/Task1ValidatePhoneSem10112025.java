public interface Task1ValidatePhoneSem10112025 {
    static boolean validatePhoneNumber(String phoneNumber) throws Task1WrongPhoneNumberExceptionSem10112025 {
        if (phoneNumber == null || phoneNumber.length() < 7 || !phoneNumber.matches("\\d+")) {
            throw new Task1WrongPhoneNumberExceptionSem10112025("Invalid phone number");
        }
        return true;
    }
}
