public class Task1NoMoreProductsExceptionSem10112025 extends Exception {
    public Task1NoMoreProductsExceptionSem10112025(String message) {
        super(message);
    }
}
